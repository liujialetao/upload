package com.atguigu.spring5.dao;

public interface UserDao {
    public void update();
}
