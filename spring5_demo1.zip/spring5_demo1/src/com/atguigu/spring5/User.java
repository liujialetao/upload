package com.atguigu.spring5;

public class User {
//    private System name;
//
//    public User(System name) {
//        this.name = name;
//    }

    public void add(){
        System.out.println("add ...");
    }
}



